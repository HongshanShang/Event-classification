from __future__ import division

import numpy as np
import mel_features
import vggish_params
import resampy  

def preprocess_audio(waveform, original_rate):
    """
    Converts audio waveform into an array of examples for VGGish
    Parameters:
    waveform: numpy array, either 1D (mono) or 2D (multichannel, with outer dimension being channels).
    The samples are assumed to be in the range [-1.0, +1.0], but this is not required.
    original_rate: The original sampling rate of the audio data.

    Returns:
        A 3D array of shape [num_samples, num_frames, num_bands], representing a sequence of samples,
        each containing a logarithmic Mel spectrogram tile covering num_frames frames and num_bands Mel bands.
    """
    # Mono processing
    if waveform.ndim > 1:
        waveform = np.mean(waveform, axis=1)

    # Resample to the rate assumed by VGGish.
    if original_rate != vggish_params.SAMPLE_RATE:
        waveform = resampy.resample(waveform, original_rate, vggish_params.SAMPLE_RATE)

    # Calculate the log Mel spectrum features
    log_mel_spectrogram = mel_features.log_mel_spectrogram(
        waveform,
        audio_sample_rate=vggish_params.SAMPLE_RATE,
        log_offset=vggish_params.LOG_OFFSET,
        window_length_secs=vggish_params.STFT_WINDOW_LENGTH_SECONDS,
        hop_length_secs=vggish_params.STFT_HOP_LENGTH_SECONDS,
        num_mel_bins=vggish_params.NUM_MEL_BINS,
        lower_edge_hertz=vggish_params.MEL_MIN_HZ,
        upper_edge_hertz=vggish_params.MEL_MAX_HZ)

    # Frame features into examples.
    sample_rate_of_features = 1.0 / vggish_params.STFT_HOP_LENGTH_SECONDS
    example_window_length = int(round(vggish_params.EXAMPLE_WINDOW_SECONDS * sample_rate_of_features))
    example_hop_length = int(round(vggish_params.EXAMPLE_HOP_SECONDS * sample_rate_of_features))
    samples = mel_features.frame(
        log_mel_spectrogram,
        window_length=example_window_length,
        hop_length=example_hop_length)
    return samples

if __name__ == '__main__':
    sample_rate, data = wavfile.read('example.wav')
    processed_audio = preprocess_audio(data, sample_rate)
    print(processed_audio.shape)
