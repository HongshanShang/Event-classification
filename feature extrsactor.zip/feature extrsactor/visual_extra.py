from keras.applications.densenet import DenseNet201, preprocess_input
from keras.preprocessing import image
from tensorflow.keras.utils import to_categorical
import numpy as np
import os
import argparse
import pickle
import shutil
import datetime

parser = argparse.ArgumentParser(description='Visual Feature Extractor')
parser.add_argument('--data_path', type=str, default="AVE_Dataset", help='Path to dataset')
parser.add_argument('--save_path', type=str, default="data", help='Path for saving data')
parser.add_argument('--split', type=str, default="test", help='Dataset split (e.g., "train", "test")')
args = parser.parse_args()

current_time = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

classes_AVE = {
    # Define class labels and corresponding indices
    'Accordion': 0, 'Acoustic guitar': 1, 'Baby cry, infant cry': 2, 'Banjo': 3,
    'Bark': 4, 'Bus': 5, 'Cat': 6, 'Chainsaw': 7, 'Church bell': 8, 'Clock': 9,
    'Female speech, woman speaking': 10, 'Fixed-wing aircraft, airplane': 11,
    'Flute': 12, 'Frying (food)': 13, 'Goat': 14, 'Helicopter': 15, 'Horse': 16,
    'Male speech, man speaking': 17, 'Mandolin': 18, 'Motorcycle': 19,
    'Race car, auto racing': 20, 'Rodents, rats, mice': 21, 'Shofar': 22,
    'Toilet flush': 23, 'Train horn': 24, 'Truck': 25, 'Ukulele': 26, 'Violin, fiddle': 27
}


def DenseNet_extractor(frame_rate=16, video_length=10):
    model = DenseNet201(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    for n, file in enumerate(open(os.path.join(args.data_path, args.split + "Set.txt"), 'r').read().split('\n')):
        if file:
            print(f'{n}/{len(lines) - 1}')
            video_name = file.split('&')[1]
            video_folder = os.path.join('tmp' + args.split, video_name)
            os.makedirs(video_folder, exist_ok=True)

            video_path = os.path.join(args.data_path, 'AVE', video_name + '.mp4')
            img_folder = os.path.join(video_folder, 'img')
            os.system(
                f"ffmpeg -hide_banner -loglevel panic -i {video_path} -vf fps={frame_rate} -t {video_length} {img_folder}%04d.jpg")

            if not os.path.exists(os.path.join(img_folder, 'img0160.jpg')):
                shutil.copy(os.path.join(img_folder, 'img0159.jpg'), os.path.join(img_folder, 'img0160.jpg'))

            # Feature extraction
            frames = [preprocess_input(image.img_to_array(
                image.load_img(os.path.join(img_folder, f'img{idx:04d}.jpg'), target_size=(224, 224)))) for idx in
                      range(1, video_length * frame_rate + 1)]
            features = model.predict(np.array(frames)).mean(axis=(1, 2))
            video_feature.append(
                [features[frame_rate * j: frame_rate * (j + 1), :].mean(axis=0) for j in range(video_length)])
            target.append(to_categorical(classes_AVE[file.split('&')[0]], num_classes=28))

    # Saving the extracted features and targets
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)

    with open(os.path.join(args.save_path, f"{current_time}{args.split}Set_visual.p"), 'wb') as f:
        pickle.dump(np.array(video_feature), f)
    with open(os.path.join(args.save_path, f"{current_time}{args.split}Set_target.p"), 'wb') as f:
        pickle.dump(np.array(target), f)


if __name__ == '__main__':
    DenseNet_extractor()
