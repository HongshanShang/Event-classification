from __future__ import print_function
from __future__ import absolute_import

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Flatten, Dense, Input, Conv2D, MaxPooling2D, GlobalAveragePooling2D, GlobalMaxPooling2D
from keras.utils.layer_utils import get_source_inputs
from keras import backend as K

import vggish_params as params

# define weight path
WEIGHTS_PATH_NO_TOP = 'vggish_audioset_weights_without_fc2.h5'
WEIGHTS_PATH_WITH_TOP = 'vggish_audioset_weights.h5'

def VGGish(include_top=True, weights='audioset', input_tensor=None, input_shape=None,
           output_dim=None, pooling='avg', load_weights=True):
    """
    Implementation of the VGGish model architecture.

    Parameters:
    - include_top: whether to include the fully connected layer at the top of the network
    - weights: a choice of pre-trained weights, can be 'audioset' or None
    - input_tensor: an optional Keras tensor for the layer input
    - input_shape: the shape of the input data
    - output_dim: the dimension of the output layer
    - pooling: the pooling method to use when excluding the top layer, can be 'avg' or 'max'
    - load_weights: whether to load pre-trained weights

    Returns:
    - Keras model instance
    """

    if weights not in {'audioset', None}:
        raise ValueError('`weights` should be `None` (random initialization) or `audioset`（pre-training on audioset）。')

    if output_dim is None:
        output_dim = params.EMBEDDING_SIZE

    if input_shape is None:
        input_shape = (params.NUM_FRAMES, params.NUM_BANDS, 1)

    if input_tensor is None:
        aud_input = Input(shape=input_shape, name='input_1')
    else:
        if not K.is_keras_tensor(input_tensor):
            aud_input = Input(tensor=input_tensor, shape=input_shape, name='input_1')
        else:
            aud_input = input_tensor

    # Constructing the convolutional layer part of VGGish
    vggish_input = Conv2D(64, (3, 3), activation='relu', padding='same', name='block1_conv1')(aud_input)
    vggish_input = MaxPooling2D((2, 2), padding='same', name='block1_pool')(vggish_input)
    vggish_input = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv1')(vggish_input)
    vggish_input = MaxPooling2D((2, 2), padding='same', name='block2_pool')(vggish_input)
    vggish_input = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv1')(vggish_input)
    vggish_input = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv2')(vggish_input)
    vggish_input = MaxPooling2D((2, 2), padding='same', name='block3_pool')(vggish_input)
    vggish_input = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv1')(vggish_input)
    vggish_input = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv2')(vggish_input)
    vggish_input = MaxPooling2D((2, 2), padding='same', name='block4_pool')(vggish_input)

    if include_top:
        vggish_input = Flatten(name='flatten')(vggish_input)
        vggish_input = Dense(4096, activation='relu', name='fc1')(vggish_input)
        vggish_input = Dense(4096, activation='relu', name='fc2')(vggish_input)
        vggish_input = Dense(output_dim, activation='relu', name='predictions')(vggish_input)
    else:
        if pooling == 'avg':
            vggish_input = GlobalAveragePooling2D(name='global_avg_pool')(vggish_input)
        elif pooling == 'max':
            vggish_input = GlobalMaxPooling2D(name='global_max_pool')(vggish_input)

    if not input_tensor:
        inputs = aud_input
    else:
        inputs = get_source_inputs(input_tensor)

    # build model
    model = Model(inputs, vggish_input, name='VGGish')

    # load weight
    if load_weights:
        if weights == 'audioset':
            if include_top:
                model.load_weights(WEIGHTS_PATH_WITH_TOP)
            else:
                model.load_weights(WEIGHTS_PATH_NO_TOP)
        else:
            print("failed")

    return model
