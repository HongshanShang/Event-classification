from __future__ import division
#important model
from tensorflow.keras.models import Model
from vggish import VGGish  
from preprocess_sound import preprocess_sound  
import numpy as np
from scipy.io import wavfile  
import os
import argparse
import pickle
import datetime

# Set time label
current_time = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

parser = argparse.ArgumentParser(description='audio_feature_extractor')
parser.add_argument('--data_path', type=str, default="AVE_Dataset", help='AVE_Dataset')
parser.add_argument('--save_path', type=str, default="data", help='save_path')
parser.add_argument('--split', type=str, default="train", help='dataset split type')
args = parser.parse_args()


def VGGish_extractor(video_length=10, window_length=1):
    sound_model = VGGish(include_top=False, load_weights=True)
    sound_extractor = Model(inputs=sound_model.input, outputs=sound_model.get_layer("conv4/conv4_2").output)

    audio_features = []
    with open(os.path.join(args.data_path, args.split + "Set.txt"), 'r') as file:
        lines = [line.strip() for line in file if line.strip() and line.split('&')[1] != 'VideoID']
        
# Make sure the temporary directory exists
    os.makedirs('tmp', exist_ok=True)  

    for n, line in enumerate(lines):
        print(f'{n}/{len(lines) - 1}')
        video_name = line.split('&')[1]
        video_path = os.path.join(args.data_path, 'AVE', f'{video_name}.mp4')
        audio_path = os.path.join('tmp', f'{video_name}.wav')

        # Extract audio from video
        os.system(f"ffmpeg -hide_banner -loglevel panic -i {video_path} -t {video_length} {audio_path}")

        # load audio file
        sr, wav_data = wavfile.read(audio_path)
        audio_samples = [preprocess_sound(wav_data[sr * i * window_length: sr * (i + 1) * window_length] / 32768.0, sr)
                         for i in range(video_length)]
        audio_features.append(sound_extractor.predict(np.array(audio_samples)))

        os.remove(audio_path)  # Clean up temporary audio files

    # Store the extracted audio features
    os.makedirs(args.save_path, exist_ok=True)
    feature_path = os.path.join(args.save_path, f"{current_time}{args.split}Set_audio_vggish.p")
    with open(feature_path, 'wb') as f:
        pickle.dump(np.array(audio_features), f, protocol=4)


if __name__ == '__main__':
    VGGish_extractor()
