import numpy as np
from scipy.io import wavfile

def slice_frames(data, frame_size, stride):
    """Split the signal into overlapping frames.
        Parameters:
        data: 1D array of signal.
        frame_size: number of samples per frame.
        stride: stride between frames.
        Returns:
          2D array of overlapping frames.
    """
    num_samples = len(data)
    num_frames = 1 + (num_samples - frame_size) // stride
    return np.lib.stride_tricks.as_strided(data, shape=(num_frames, frame_size), strides=(data.strides[0] * stride, data.strides[0]))

def hann_window(length):

    return 0.5 - 0.5 * np.cos(2 * np.pi / length * np.arange(length))

def magnitude_stft(signal, fft_size, step_size, window_size):
    """Generates a periodic Hann window.
      Parameters:
      length: length of the window.
      Returns:
        Hann windows.
    """
    frames = slice_frames(signal, window_size, step_size)
    window = hann_window(window_size)
    return np.abs(np.fft.rfft(frames * window, n=fft_size))

def convert_freq_to_mel(freq):
    
    return 1127.0 * np.log(1.0 + freq / 700.0)

def create_mel_filter(num_mel_bins, num_fft_bins, sample_rate, low_freq, high_freq):
    """Build a Mel filter matrix.
      Parameters:
      num_mel_bins: Number of Mel filter banks.
      num_fft_bins: Number of bins there are in the source spectrogram data
      low_freq: Lowest frequency boundary of the Mel filter.
      high_freq: Highest frequency boundary.
      Returns:
        Mel filter matrix.
    """
    nyquist = sample_rate / 2
    if low_freq >= high_freq:
        raise ValueError("Low frequency must be less than high frequency.")
    mel_edges = np.linspace(convert_freq_to_mel(low_freq), convert_freq_to_mel(high_freq), num_mel_bins + 2)
    bin_freqs = np.linspace(0, nyquist, num_fft_bins)
    mel_filter = np.zeros((num_fft_bins, num_mel_bins))
    for i in range(num_mel_bins):
        lower, center, upper = mel_edges[i:i+3]
        mel_filter[:, i] = np.maximum(0, np.minimum((bin_freqs - lower) / (center - lower), (upper - bin_freqs) / (upper - center)))
    return mel_filter

def compute_log_mel_spectrogram(data, sample_rate, window_sec=0.025, hop_sec=0.010):
    """Computes a log-Mel spectrogram from a signal.
        Parameters:
        data: 1D array of signal.
        sample_rate: sampling rate.
        window_sec: duration of each analysis window.
        hop_sec: step size between windows.
      Returns:
        log-Mel spectrogram.
    """
    window_samples = int(round(sample_rate * window_sec))
    hop_samples = int(round(sample_rate * hop_sec))
    fft_length = 2 ** int(np.ceil(np.log2(window_samples)))
    spectrogram = magnitude_stft(data, fft_length, hop_samples, window_samples)
    mel_matrix = create_mel_filter(20, spectrogram.shape[1], sample_rate, 125, 3800)
    mel_spectrogram = np.dot(spectrogram, mel_matrix)
    return np.log(mel_spectrogram + 1e-6)  
  

if __name__ == '__main__':
# Sample signal loading
    sample_rate, data = wavfile.read('example.wav')
    log_mel_spec = compute_log_mel_spectrogram(data, sample_rate)
    print(log_mel_spec)
