# Defines parameters for audio processing and model training.
NUM_FRAMES = 96  # Number of frames in each Mel-spectrogram
NUM_BANDS = 64  # Number of frequency bands in the Mel spectrum
EMBEDDING_DIM = 128  # Size of embedding layer

# Hyperparameters used in feature and example generation。
SAMPLE_RATE = 16000
WINDOW_DURATION = 0.025  # 。
HOP_DURATION = 0.010  # Duration of the STFT window (seconds)
MEL_BINS = NUM_BANDS  # The number of Mel filters.
FREQ_MIN_HZ = 125  # The lowest frequency of the Mel spectrum.
FREQ_MAX_HZ = 7500  # The highest frequency of the Mel spectrum.
STABILIZATION_CONSTANT = 0.01  # Offset used for stabilized log of input mel-spectrogram
SAMPLE_WINDOW = 0.96  # The length of the sample window in seconds.
SAMPLE_HOP = 0.96  # with zero overlap.

# Parameters used for embedding postprocessing
PCA_VECTORS_KEY = 'pca_eigen_vectors'  # The keys of the PCA vectors.
PCA_MEANS_KEY = 'pca_means'  # Key for PCA mean
QUANTIZE_MIN = -2.0  # Minimum value for quantization.
QUANTIZE_MAX = +2.0  # The maximum value of quantization.

# Training hyperparameters.
WEIGHT_INIT_STDDEV = 0.01  # Standard deviation used to initialize weights.
LEARNING_RATE = 1e-4  # Learning rate for the Adam optimizer.
ADAM_EPSILON = 1e-8  # Epsilon for the Adam optimizer.

# Names of ops, tensors, and features
INPUT_FEATURES_OP = 'vggish/input_features'  
INPUT_FEATURES_TENSOR = INPUT_FEATURES_OP + ':0'  
EMBEDDING_OP = 'vggish/embedding'  
EMBEDDING_TENSOR = EMBEDDING_OP + ':0'  
AUDIO_EMBEDDING_KEY = 'audio_embedding' 


